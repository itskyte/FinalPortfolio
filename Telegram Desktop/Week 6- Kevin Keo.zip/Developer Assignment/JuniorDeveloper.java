public class JuniorDeveloper extends Developer {
	
	public JuniorDeveloper(String job, String name, int basicSalary, int experience) {
		super(job, name, basicSalary, experience);

	}
	public int getSalary() {
		return (int) (basicSalary + (basicSalary* experience * 0.2));
	}
	public String showInfo() {
		return ("My name is "+name+". I am "+job+" and my salary is "+getSalary());
	}

}


