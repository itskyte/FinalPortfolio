
public class main {

	public static void main(String[] args) {
		System.out.println("========================================================================");
		System.out.println("--------------------WELCOME TO ALPHA X IT SOLUTION----------------------");
		System.out.println("========================================================================");
		Developer[] Developer = {
		
		 new SeniorDeveloper("Senior Web Developer","Kevin", 1200, 3),
		 new SeniorDeveloper("Senior Java Developer","Pheavan", 1200, 1),
		 new SeniorDeveloper("Senior Python Developer","SokLeng", 1200, 2),
		 new SeniorDeveloper("Senior Project Developer","Pitou", 1200, 1),
		 new SeniorDeveloper("Senior Web Developer","Panhavath", 1200, 2),
		 
		 new JuniorDeveloper("Junior Web Developer","Gechsim", 1000, 3),
		 new JuniorDeveloper("Junior PHP Developer","Dolly", 1000, 2),
		 new JuniorDeveloper("Junior Java Developer","Jake", 1000, 2),
		 new JuniorDeveloper("Junior Web Developer","Finn", 1000, 2),
		 new JuniorDeveloper("Junior Project Manager","Ippo", 1000, 3),
		 
		 new Intern("Web Developer Intern","Robert", 300, 1),
		 new Intern("Database Developer Intern","Thomus", 300, 1),
		 new Intern("Python Developer Intern","Albert", 300, 1),
		 new Intern("Android Developer Intern","Jenny", 300, 1),
		 new Intern("C++ Developer Intern","Linda", 300, 1),
		};
		System.out.println("Developer with a salary more than $1500:");
		
		for (int i=0; i<Developer.length; i++) {
			if(Developer[i].getSalary()>1500) {
				System.out.println(Developer[i].showInfo()+"$ .");
			}
		}
	}

}
