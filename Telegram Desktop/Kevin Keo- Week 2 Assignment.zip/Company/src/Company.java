public class Company {
public static void main(String[] args) {
	System.out.println("-----------------------------------------------");
	System.out.println("WELCOME TO ALPHA X COORPORATION");	
	System.out.println("-----------------------------------------------");
	Employee Kevin = new Employee("Kevin Keo","Sale and Marketing","Marketing Manager",21,3200);
	Kevin.show();
	Kevin.salaryBySemester(3200);
	Kevin.salaryByYear(3200, 4);
	System.out.println("-----------------------------------------------");
	
	Employee Thomus = new Employee("Thomus Edward","IT office","IT admin",22,2200);
	Thomus.show();
	Thomus.salaryBySemester(2200);
	Thomus.salaryByYear(2200, 5);
	System.out.println("-----------------------------------------------");

	Employee Egnot = new Employee(" Egnot Alber","Finance and Accounting","Accountant",23,2000);
	Egnot.show();
	Egnot.salaryBySemester(2000);
	Egnot.salaryByYear(2000, 3);
	
	System.out.println();
	
	System.out.println("-----------------------------------------------");
	
	Employee total= new Employee();
	total.totalEmployee(300,300,300);
	total.totalBudget(1200000, 2330000, 3400000);


	
}
}

