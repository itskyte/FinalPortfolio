public class Employee {
public String name;
private int age;
private int salary;
private String department;
private String occupation;

public Employee() {
}

public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}
public String getOccupation(){
	return occupation;
}
public void setOccupation(String occupation) {
	this.occupation = occupation;
}

public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}

public Employee(String name) {
	this.name = name;
}
public Employee(String department, String occupation ,int age, int salary) {
	this.department = department;
	this.occupation = occupation;
	this.age = age;
	this.salary = salary;
}
public Employee(String name, String department, String occupation ,int age, int salary) {
	this.name = name;
	this.department = department;
	this.occupation= occupation;
	this.age = age;
	this.salary = salary;
}
public void salaryBySemester(int Salary) {
	int semester = 6;
	int sum = Salary*semester;
	System.out.println("My Salary in a semester is " + sum + " dollars.");
}
public void salaryByYear(int Salary, int year) {
	int month=12; 
	int yearSum = Salary*month;
	int maxSalary = yearSum*year;
	System.out.println("My Salary in " + year + " year is " + maxSalary +" dollars.");
}
public void totalEmployee(int accEmployee, int itEmployee, int saleEmployee) {
	int totalEmployee = accEmployee + itEmployee + saleEmployee;
	System.out.println("This company has a total of " + totalEmployee + " employees.");
}
public void totalBudget(int accBudget, int itBudget, int saleBudget) {
	int otherBudget= 34000;
	int totalBudget = accBudget + itBudget + saleBudget + otherBudget;
	System.out.println("This company spends its budget around " + totalBudget + " dollars a year.");
}

public void show() {
	System.out.println("Name: " + name);
	System.out.println("Department: " +getDepartment());
	System.out.println("Occupation: " +getOccupation());
	System.out.println("Age: " +getAge());
	System.out.println("Salary: " + getSalary());
} 
}
